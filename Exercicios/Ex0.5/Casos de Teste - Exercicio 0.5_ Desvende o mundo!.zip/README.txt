Arquivo zip gerado em: 18/08/2025 20:08:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 0.5: Desvende o mundo!