Arquivo zip gerado em: 21/09/2025 21:52:29 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 05: Ultrapassagens no Leo Kart